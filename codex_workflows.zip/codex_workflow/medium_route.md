# Medium Route

Use this workflow only after the Medium route has been selected under `AGENTS.md`.

## Main-Agent Role

You are the main agent and perform the work directly without spawning or delegating to subagents.

Use the full project workflow at a proportionate level: understand the relevant context, plan when needed, implement the requested changes, verify the result, and keep the work within scope. Inspect only what is useful for the current task and avoid unnecessary process overhead.

## Plans and Status Writes

When the user says **"plan the implementation for..."** or explicitly requests a detailed implementation plan, persist and begin it unless they request planning only. 

Record:

* Goal and scope.
* Constraints and protected areas.
* Acceptance criteria.
* Major implementation steps when useful.
* Dependencies, verification approach, known blockers, and next action.

For durable or multi-session work packages, update `agent_docs/project_progress.md` at most twice:

1. Mark the package active and record its bounded plan.
2. Reconcile final status, verification evidence, blockers, and next action.

Do not update it after every checkpoint. Keep significant changes to the plan understandable and traceable.

## Documentation

Update durable documentation only when architecture, structure, workflow, public behavior, significant decisions, or module usage changes.

Use verified implementation and test results as the source of truth. Update `agent_docs/project_diary.md` only for decisions, discarded approaches, or lessons with lasting architectural value.

## Working Rules

Keep changes focused and preserve unrelated user work. Perform verification appropriate to the risk and scope of the task. Do not claim unrun checks passed, hide blockers, or broaden the task without a clear need.

## Blockers

When blocked, record:

- The failed step and exact evidence.
- The suspected cause.
- Completed changes and current repository state.
- The affected acceptance criterion.
- The decision, dependency, or external input required.

Do not disguise partial work as completion. Adjust the plan and preserve a clear continuation point.

## End-of-Session Handoff

Run this section only when the user directly commands the exact phrase `end this session`, ignoring capitalization and surrounding punctuation.

1. Confirm verification occurred after the last relevant code or test change; do not rerun solely because the session is ending.
2. Perform concise final status, diff statistics, whitespace or error checks, and targeted changed-file review.
3. Reconcile `project_progress.md` with the final status, verification evidence, blockers, and next action if its recorded state has changed. Refresh/empty it content if the plan is complete.
4. Replace `latest_session_work.md` once with changes, verification, pending work, blockers, and the next entry point.
5. Update durable docs only when warranted and `project_diary.md` only for significant decisions or lessons.
6. If meaningful project files changed, run `git add .` and commit with `git commit -m "[auto commit] <summary>"`.

If no meaningful project files changed, there is no need to refresh `latest_session_work.md`.

Every completed session must leave honest status, bounded changes, current verification, preserved user work, and a clear continuation point.