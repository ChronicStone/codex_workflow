# Workflow Setup Guide
Set up the custom workflow for the current project. No need to read or change any source-code files in this task.

## 1. Install the default workflow

1. Keep `AGENTS.md` in the root directory of the current project.

2. Create the following directories:

   ```text
   agent_docs/
   agent_docs/workflows/
   ```
3. Initialize the main project documents inside `agent_docs/`.

4. Move the workflow route files:

   ```text
   heavy_route.md  → agent_docs/workflows/heavy_route.md
   medium_route.md → agent_docs/workflows/medium_route.md
   ```

5. Create the Codex user agent directory if it does not already exist:

   - Ubuntu and macOS: `~/.codex/agents/`
   - Windows PowerShell: `$HOME\.codex\agents\`

6. Move the following agent definitions into that directory:

   ```text
   doc-writer.toml
   tester.toml
   executor_luna.toml
   executor_sol.toml
   ```

7. If a destination file already exists, ask the user before replacing it.

8. Verify that all files and directories are in the correct locations, then report the installation result.

## 2. Configure the project (advanced)

After installation, read the installed files to understand the workflow.

Ask the following questions one at a time.

### Core design principles

Ask:

> Would you like to define the work style and core design principles for this project?

This question is optional. If the user provides an answer, write it under `## Core Design Principles` in `AGENTS.md`.

### Power profile

Explain that the default workflow is optimized to save tokens on the ChatGPT Plus plan.

Ask whether the user wants to enable any of the following options:

1. Allow more than three agents and remove the limit of one `executor_sol` subagent.
2. Set `executor_luna` and `tester` to the maximum reasoning level.
3. Allow more detailed subagent reports. Event and final reports are currently limited to 150 and 250 words.
4. Allow more than two retries before replacing a stuck or blocked subagent. A replacement must reload its context packet, which consumes additional tokens but can reduce the risk of the task remaining stuck.

Ask the user to select the individual options they want. Do not enable all options based only on a general “yes.”

Apply the selected changes to the corresponding `.toml` and `.md` files, verify the new values, and report what was changed.