# AGENTS.md

## Project Context

## Core Design Principles

The project must strictly follow modular design.

Each module should have:

- A clear responsibility.
- A clear interface.
- Minimal unnecessary coupling.
- A structure that makes it easy to test, debug, replace, extend, and reuse.

Nested modules are allowed when they make responsibilities clearer. Avoid placing unrelated responsibilities into the same file, class, service, or large function.

- Prioritize designing test cases before starting deployment.
- Tests should not be too detailed and separate; prioritize grouping them together to avoid wasting tokens and prolonging testing time.

## Working State

At any given time, we will be in one of two working states:
- `deployment state`: beginning to plan a broad task or in the process of deploying a plan. A  deployment plan can span multiple sessions.
- `leaf state`: for tasks outside the plan being deployed by the `deployment state`, such as general queries, document editing, or performing operations to add, modify, or delete small files, modules, or tools.

## Project Documentation Framework

The main project documents are stored under `agent_docs/`:

- `agent_docs/project_overview.md`: goals, architecture, workflows, and major decisions.
- `agent_docs/project_core_tech.md`: quantization, storage, tree, and adaptation contracts; edit only when explicitly requested.
- `agent_docs/project_structure.md`: directory layout, modules, components, and ownership boundaries.
- `agent_docs/project_progress.md`: active implementation plan and cross-session execution status.
- `agent_docs/project_diary.md`: durable architecture decisions, discarded approaches, and lessons.
- `agent_docs/latest_session_work.md`: Summarizing previous sessions along with any unfinished tasks.
- Module-specific documents, when present.

--------
`agent_docs/project_progress.md` and `agent_docs/latest_session_work.md` are two documents designed to ensure smooth and seamless deployment between multiple sessions in deployment mode. These two files can only be edited in `deployment state` or when the user explicitly requests it. The main agent is responsible for updating these two files, while subagents are not allowed to edit them.

Update documentation only with verified facts. Keep temporary reasoning, raw logs, and short-lived checkpoints out of durable project documents.

Never delete any main project document without warning the user and receiving a second explicit confirmation.

## Route Selection

There are three workflows.
### Light route: 
Use for light tasks which in the `leaf state`.
Performs tasks by yourself. Do not spawn subagents in this route.

### Medium route: 
Use for deploying large tasks/plans in the `deployment state`.
Performs tasks by yourself. Do not spawn subagent in this route
Read and follow `agent_docs/workflows/medium_route.md`.

### Heavy route: 
You a orchestrator, coordinates subagents to deploy large tasks/plans in the `deployment state`.
Read and follow `agent_docs/workflows/heavy_route.md`.

### Route selection rules and state interpolation

The route will be specified by the user, like: "use Light/medium/heavy route...". Apply that route throughout the entire session until it ends or until the user indicates to switch to the other route. If the user does not specify a route, select the light route as the default. Do not guess and choose a route yourself.

If the light route is specified or choosed, it means we are in the `leaf state`. 
If the medium route/heavy route is specified, it means we will proceed to the `deployment state`. 

## Context Loading 
- If the light route is selected(`leaf state`), read only the relevant files for the current task if any needed.
- Once when we enter the `deployment state`, read the following files in order:
 1. read `agent_docs/project_overview.md`, `agent_docs/project_structure.md` to have a general understanding of the project.
 2. read `agent_docs/project_progress.md` and `agent_docs/latest_session_work.md` for a smooth and seamless deployment process.
 3. Use their status and ownership map to inspect the smallest relevant interface/call-site surface. 
 4. Read only relevant module documentation; expand source inspection when repository evidence requires it.
 5. reconstruct active tasks, dependencies, verification, and blockers. Reconcile contradictions with targeted evidence. Review only critical hunks and integration boundaries after delegation unless risk or conflicting evidence requires broader inspection.
